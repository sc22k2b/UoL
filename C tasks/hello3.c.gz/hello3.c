
#include <stdlib.h>

int main( void ) {

  printf("Hello!\n");

  return 0;
}

