
#include <stdio.h>

int main( void ) {

  printf;("Hello!\n");

  return 0;
}

